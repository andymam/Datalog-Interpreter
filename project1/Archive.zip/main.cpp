#include "Scanner.h"


int main(int argc, char* argv[]) {
  Scanner s;
  s.scan(argv[1]);
  return 0;
}